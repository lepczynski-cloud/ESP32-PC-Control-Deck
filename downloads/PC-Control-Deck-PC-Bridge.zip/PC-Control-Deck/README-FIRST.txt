ESP32 PC Control Deck - PC bridge

The ESP32 firmware does not monitor your computer by itself.
Install Python 3 on your computer and keep the bridge running.

Windows: Extract this ZIP, then run host\run_windows.bat.
macOS/Linux: Extract this ZIP, then run sh host/run_linux_macos.sh.
Edit host/config.json locally for your macros and serial port.
Project: https://github.com/lepczynski-cloud/ESP32-PC-Control-Deck
